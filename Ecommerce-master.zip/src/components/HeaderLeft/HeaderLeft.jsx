import React from 'react'

const HeaderLeft = () => {
  return (
    <div>SHOP</div>
  )
}

export default HeaderLeft